var struct_c___w_ftype =
[
    [ "m_bounds", "struct_c___w_ftype.html#a657c822c770e0309771df9135dbf72ab", null ],
    [ "m_dataSize", "struct_c___w_ftype.html#aa3ba2a5324985d416025b7cd4e7414b2", null ],
    [ "m_WFdata", "struct_c___w_ftype.html#a6d650c3712cccdc037d24989e1290afa", null ]
];