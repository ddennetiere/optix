var modules =
[
    [ "Interface C functions", "group__globalc.html", "group__globalc" ],
    [ "Enumeration list", "group__enums.html", "group__enums" ],
    [ "Global internal C++ functons", "group___global_cpp.html", "group___global_cpp" ]
];