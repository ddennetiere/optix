var class_grating =
[
    [ "Grating", "class_grating.html#ac6c11f3e77450797581bffd399e8c28e", null ],
    [ "~Grating", "class_grating.html#aeddfb13f21d5336c45526c89a0994d40", null ],
    [ "align", "class_grating.html#a82a7a232e9a8ae4762faad459c523040", null ],
    [ "getOptixClass", "class_grating.html#ac085881ae2caddab22007985530acfd4", null ],
    [ "setParameter", "class_grating.html#a3bc8e769032d0ffd36cfb825651efe5e", null ]
];