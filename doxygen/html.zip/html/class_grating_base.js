var class_grating_base =
[
    [ "GratingBase", "class_grating_base.html#a50031c9a169ef0f9520a78ee61ccab91", null ],
    [ "~GratingBase", "class_grating_base.html#a45aa9365c7544ae8f303e8d12d11d375", null ],
    [ "getOptixClass", "class_grating_base.html#a59428aae0cd161dd91f02f5b89e07aca", null ],
    [ "reflect", "class_grating_base.html#a7ab9abf0bdf65f0c963f834e1f3eca59", null ],
    [ "setFrameTransforms", "class_grating_base.html#a027224b4fd93d5f5f333566f75705696", null ],
    [ "transmit", "class_grating_base.html#a0cd5d1e005e34d2e4032768174ad1bfd", null ],
    [ "m_alignmentOrder", "class_grating_base.html#a1d105a568d9db78075ba3e5f2ee2c640", null ],
    [ "m_useOrder", "class_grating_base.html#ac87d93fe82d2c346979babea31ac2631", null ],
    [ "psiTransform", "class_grating_base.html#a4314251832ba47419e51f7bcc2d03fb5", null ]
];