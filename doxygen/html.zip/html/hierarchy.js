var hierarchy =
[
    [ "C_DiagramStruct", "struct_c___diagram_struct.html", null ],
    [ "C_LinkType", "struct_c___link_type.html", null ],
    [ "C_WFtype", "struct_c___w_ftype.html", null ],
    [ "ChainCopy", "struct_chain_copy.html", null ],
    [ "DiagramType< Vsize >", "class_diagram_type.html", null ],
    [ "ElementBase", "class_element_base.html", [
      [ "Surface", "class_surface.html", [
        [ "GratingBase", "class_grating_base.html", [
          [ "Grating< PatternType, SShape >", "class_grating.html", null ]
        ] ],
        [ "Holo", "class_holo.html", null ],
        [ "Plane", "class_plane.html", null ],
        [ "Poly1D", "class_poly1_d.html", null ],
        [ "Quadric", "class_quadric.html", [
          [ "Cylinder", "class_cylinder.html", null ],
          [ "Sphere", "class_sphere.html", null ]
        ] ],
        [ "SourceBase", "class_source_base.html", [
          [ "GaussianSource", "class_gaussian_source.html", null ],
          [ "RadialGridSource", "class_radial_grid_source.html", null ],
          [ "XYGridSource", "class_x_y_grid_source.html", null ]
        ] ],
        [ "Sphere", "class_sphere.html", null ],
        [ "Toroid", "class_toroid.html", null ]
      ] ]
    ] ],
    [ "fstream", null, [
      [ "SolemioFile", "class_solemio_file.html", null ],
      [ "TextFile", "class_text_file.html", null ]
    ] ],
    [ "map", null, [
      [ "ElementCollection", "class_element_collection.html", null ]
    ] ],
    [ "Parameter", "class_parameter.html", null ],
    [ "ParametrizedLine", null, [
      [ "RayBase< scalar >", "class_ray_base.html", [
        [ "Ray< scalar >", "class_ray.html", null ]
      ] ]
    ] ],
    [ "Pattern", "class_pattern.html", [
      [ "GratingBase", "class_grating_base.html", null ],
      [ "Holo", "class_holo.html", null ],
      [ "Poly1D", "class_poly1_d.html", null ]
    ] ],
    [ "PatternType", null, [
      [ "Grating< PatternType, SShape >", "class_grating.html", null ]
    ] ],
    [ "SolemioSurface", "struct_solemio_surface.html", null ],
    [ "SShape", null, [
      [ "Film< SShape >", "class_film.html", null ],
      [ "Grating< PatternType, SShape >", "class_grating.html", null ],
      [ "Mirror< SShape >", "class_mirror.html", null ]
    ] ],
    [ "vector", null, [
      [ "StringVector", "class_string_vector.html", null ]
    ] ],
    [ "WavefrontData", "struct_wavefront_data.html", null ],
    [ "runtime_error", null, [
      [ "ElementException", "class_element_exception.html", null ],
      [ "ParameterException", "class_parameter_exception.html", null ],
      [ "RayException", "class_ray_exception.html", null ],
      [ "TextFileException", "class_text_file_exception.html", null ]
    ] ]
];