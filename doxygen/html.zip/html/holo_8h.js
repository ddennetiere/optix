var holo_8h =
[
    [ "Holo", "class_holo.html", "class_holo" ],
    [ "HOLO_EULERIAN", "holo_8h.html#a58bdf0499715421e1a20fa5d22327175", null ],
    [ "HOLO_H", "holo_8h.html#a815ab9687f7674ee7e2b8304ee9a82b9", null ]
];