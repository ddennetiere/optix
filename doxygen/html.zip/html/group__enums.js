var group__enums =
[
    [ "FrameID", "group__enums.html#ga10d626c14577aaa469e804c0e08e9d38", [
      [ "GeneralFrame", "group__enums.html#gga10d626c14577aaa469e804c0e08e9d38a4660bdd26b74a6f3f9b3731dd5c28754", null ],
      [ "LocalAbsoluteFrame", "group__enums.html#gga10d626c14577aaa469e804c0e08e9d38a246373ab8f221e1599be79248424840a", null ],
      [ "AlignedLocalFrame", "group__enums.html#gga10d626c14577aaa469e804c0e08e9d38adc6be30f5b632bc9b9d065980cef9bdb", null ],
      [ "SurfaceFrame", "group__enums.html#gga10d626c14577aaa469e804c0e08e9d38aad8041bba3d76df1bb82e5dc10d757d0", null ]
    ] ],
    [ "ParameterFlags", "group__enums.html#ga7c61347857df57f65d567c1aa36aa7e0", [
      [ "NotOptimizable", "group__enums.html#gga7c61347857df57f65d567c1aa36aa7e0aeb4644cfa423fdf88993f1ef70d33c68", null ]
    ] ],
    [ "ParameterGroup", "group__enums.html#gabd71b1e0e3eaa825ce0dcb970e4b8c77", [
      [ "BasicGroup", "group__enums.html#ggabd71b1e0e3eaa825ce0dcb970e4b8c77a057f48af665a8c72e4d3615d2416ccb9", null ],
      [ "ShapeGroup", "group__enums.html#ggabd71b1e0e3eaa825ce0dcb970e4b8c77a7cb84375a685d253408af3f28e800607", null ],
      [ "SourceGroup", "group__enums.html#ggabd71b1e0e3eaa825ce0dcb970e4b8c77a929fcc24f0dd9a75c399f9a3a76e6b23", null ],
      [ "GratingGroup", "group__enums.html#ggabd71b1e0e3eaa825ce0dcb970e4b8c77a7f05d6fcfd709fcb6af8e043e7fc4ce6", null ]
    ] ],
    [ "RecordMode", "group__enums.html#ga9d89dadc7eae9423d082ce4bc9bfea5a", [
      [ "RecordNone", "group__enums.html#gga9d89dadc7eae9423d082ce4bc9bfea5aaeb62c27f7a2b9b5b69906ba489699871", null ],
      [ "RecordInput", "group__enums.html#gga9d89dadc7eae9423d082ce4bc9bfea5aa3fc8bbc5d8e96fef0c9ad6b8c20fa917", null ],
      [ "RecordOutput", "group__enums.html#gga9d89dadc7eae9423d082ce4bc9bfea5aa30c452302fa7036baae31d8634e9b179", null ]
    ] ],
    [ "UnitType", "group__enums.html#gacd6e2423e6b1ce5bead11cbb048ecc03", [
      [ "Dimensionless", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a912a7967539250da74881fd1e1a7e0c5", null ],
      [ "Angle", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a501a99846e15f9e28e3150f19a8a85fa", null ],
      [ "Distance", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03acb2a0f646b1a337a26a744bbd06989b4", null ],
      [ "InverseDistance", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a8e4c47906f7d5a16758ed0392446513c", null ],
      [ "DistanceMoins1", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a67b07f2a3c47a9428400187975fcba86", null ],
      [ "DistanceMoins2", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a5f97cf1adbd60e86087122404450820c", null ],
      [ "DistanceMoins3", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a668f42af445967af2cda78591d099cbf", null ],
      [ "DistanceMoinsN", "group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03acc46ebbbe46b6c4ead4c5c2c14abbd97", null ]
    ] ]
];