var group__globalc_global =
[
    [ "ChainElement_byID", "group__globalc_global.html#ga213799380b2101041c8088c0f1b6d874", null ],
    [ "ChainElement_byName", "group__globalc_global.html#ga2a9dc0f2fd7e984dac8f03a8cb0a05e5", null ],
    [ "CreateElement", "group__globalc_global.html#ga1f5077236b4a892ccce5fc4919d9f582", null ],
    [ "GetElementID", "group__globalc_global.html#ga6ad81b59e9111525013a244a70aefb42", null ],
    [ "GetElementName", "group__globalc_global.html#ga99a025476dc95faaf3514fd5affd1df4", null ],
    [ "GetNextElement", "group__globalc_global.html#ga1c6478b2a06af29437c8013babdf004c", null ],
    [ "GetPreviousElemente", "group__globalc_global.html#gadd8c1dbb3d7503d86bf304bf0eba7af8", null ],
    [ "RemoveElement_byID", "group__globalc_global.html#ga0de3eef16511eb229eb78c6bcbd6a3e2", null ],
    [ "RemoveElement_byName", "group__globalc_global.html#ga0c651bd5a47d85090acb93a3dbc58a75", null ]
];