var struct_c___diagram_struct =
[
    [ "m_count", "struct_c___diagram_struct.html#a0d040b72df55ad8c32c0d7032b748bad", null ],
    [ "m_dim", "struct_c___diagram_struct.html#a8f31eb803d0f80b1d09b25d865be97b2", null ],
    [ "m_lost", "struct_c___diagram_struct.html#ab5ea1961fc869a202ffd139ff8eb2ec7", null ],
    [ "m_max", "struct_c___diagram_struct.html#af326f63643b68b3c6d8909408c369de0", null ],
    [ "m_mean", "struct_c___diagram_struct.html#a0acef82a2bcdca4d62c59ed19759772f", null ],
    [ "m_min", "struct_c___diagram_struct.html#a54b8ead165376186bddb5a217d5aa657", null ],
    [ "m_reserved", "struct_c___diagram_struct.html#ace1915c3e5376aeb3ceddb2ba924ac2c", null ],
    [ "m_sigma", "struct_c___diagram_struct.html#afc21376de75d441b1589dd1eb067648c", null ],
    [ "m_spots", "struct_c___diagram_struct.html#a5aa7f6c43f9bb9adfd50179a6932682a", null ]
];