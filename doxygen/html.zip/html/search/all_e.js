var searchData=
[
  ['quadric_206',['Quadric',['../class_quadric.html',1,'Quadric'],['../class_quadric.html#a95c3ee05907c6f38a065c39aa889907d',1,'Quadric::Quadric()']]],
  ['quadric_2ecpp_207',['quadric.cpp',['../quadric_8cpp.html',1,'']]],
  ['quadric_2eh_208',['quadric.h',['../quadric_8h.html',1,'']]]
];
