var searchData=
[
  ['interface_20c_20functions_655',['Interface C functions',['../group__globalc.html',1,'']]]
];
