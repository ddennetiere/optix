var searchData=
[
  ['inversedistance_642',['InverseDistance',['../group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a8e4c47906f7d5a16758ed0392446513c',1,'types.h']]]
];
