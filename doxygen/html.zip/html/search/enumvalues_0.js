var searchData=
[
  ['alignedlocalframe_631',['AlignedLocalFrame',['../group__enums.html#gga10d626c14577aaa469e804c0e08e9d38adc6be30f5b632bc9b9d065980cef9bdb',1,'types.h']]],
  ['angle_632',['Angle',['../group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a501a99846e15f9e28e3150f19a8a85fa',1,'types.h']]]
];
