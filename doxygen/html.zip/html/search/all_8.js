var searchData=
[
  ['intercept_110',['intercept',['../class_plane.html#a2bc0812eb3f0468b2f8293c3aa24e54c',1,'Plane::intercept()'],['../class_quadric.html#a39a6018ce6a029ccb3b3f0f6668efac1',1,'Quadric::intercept()'],['../class_source_base.html#aa5031e6ba93b6ac4ecd04b15ac4a83f9',1,'SourceBase::intercept()'],['../class_surface.html#ac81115fd98287569a5f3e88bb41d2cd0',1,'Surface::intercept()'],['../class_toroid.html#adc2aee24ece161279cf50f9c14218b6e',1,'Toroid::intercept()']]],
  ['interface_20c_20functions_111',['Interface C functions',['../group__globalc.html',1,'']]],
  ['interface_2ecpp_112',['interface.cpp',['../interface_8cpp.html',1,'']]],
  ['interface_2eh_113',['interface.h',['../interface_8h.html',1,'']]],
  ['inversedistance_114',['InverseDistance',['../group__enums.html#ggacd6e2423e6b1ce5bead11cbb048ecc03a8e4c47906f7d5a16758ed0392446513c',1,'types.h']]],
  ['isaligned_115',['isAligned',['../class_element_base.html#a0a5b6cc988bd9ecda088232bfa337903',1,'ElementBase']]],
  ['iselementvalid_116',['IsElementValid',['../group__globalc.html#ga4f91ed3335da3ec7d0f8b3a867b0acdd',1,'IsElementValid(size_t ID):&#160;interface.cpp'],['../group__globalc.html#ga4f91ed3335da3ec7d0f8b3a867b0acdd',1,'IsElementValid(size_t ID):&#160;interface.cpp']]],
  ['issource_117',['isSource',['../class_element_base.html#a269fccdc048cb1a3d735cd651c0172a1',1,'ElementBase']]]
];
