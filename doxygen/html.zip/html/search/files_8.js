var searchData=
[
  ['quadric_2ecpp_373',['quadric.cpp',['../quadric_8cpp.html',1,'']]],
  ['quadric_2eh_374',['quadric.h',['../quadric_8h.html',1,'']]]
];
