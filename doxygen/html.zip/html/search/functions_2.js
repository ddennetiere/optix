var searchData=
[
  ['definedirection2_409',['defineDirection2',['../class_holo.html#abd70edb5b018c163b39a90b70b5c078d',1,'Holo']]],
  ['defineparameter_410',['defineParameter',['../class_element_base.html#a324b7c01afaa40d313ef147feec2b74a',1,'ElementBase']]],
  ['deleteelement_5fbyid_411',['DeleteElement_byID',['../group__globalc.html#ga953964bdad93e4f29e89366e281794cc',1,'DeleteElement_byID(size_t elementID):&#160;interface.cpp'],['../group__globalc.html#ga953964bdad93e4f29e89366e281794cc',1,'DeleteElement_byID(size_t elementID):&#160;interface.cpp']]],
  ['deleteelement_5fbyname_412',['DeleteElement_byName',['../group__globalc.html#gaf7f29d018890b6adcf08f761bad7c994',1,'DeleteElement_byName(const char *name):&#160;interface.cpp'],['../group__globalc.html#gaf7f29d018890b6adcf08f761bad7c994',1,'DeleteElement_byName(const char *name):&#160;interface.cpp']]],
  ['direction_413',['direction',['../class_ray_base.html#a6d8ff5ce1fff93760b7021a3fd2689b9',1,'RayBase']]],
  ['duplicatechain_414',['DuplicateChain',['../group___global_cpp.html#gad619a181248b9196434360c6899b4ee3',1,'DuplicateChain(ElementBase *source, ChainCopy &amp;newChain):&#160;opticalelements.cpp'],['../group___global_cpp.html#gad619a181248b9196434360c6899b4ee3',1,'DuplicateChain(ElementBase *source, ChainCopy &amp;newChain):&#160;opticalelements.cpp']]]
];
