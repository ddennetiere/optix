var searchData=
[
  ['legendreintegrateslopes_118',['LegendreIntegrateSlopes',['../wavefront_8cpp.html#aa69773f94375394ef03088dbd80d4495',1,'LegendreIntegrateSlopes(int Nx, int Ny, const Ref&lt; ArrayX4d &gt; &amp;WFdata, const Ref&lt; Array2d &gt; &amp;Xaperture, const Ref&lt; Array2d &gt; &amp;Yaperture):&#160;wavefront.cpp'],['../wavefront_8h.html#aa69773f94375394ef03088dbd80d4495',1,'LegendreIntegrateSlopes(int Nx, int Ny, const Ref&lt; ArrayX4d &gt; &amp;WFdata, const Ref&lt; Array2d &gt; &amp;Xaperture, const Ref&lt; Array2d &gt; &amp;Yaperture):&#160;wavefront.cpp']]],
  ['loadsolemiofile_119',['LoadSolemioFile',['../group__globalc.html#gab7fdb4362973b751c1955eb69f065f50',1,'LoadSolemioFile(char *filename):&#160;interface.cpp'],['../group__globalc.html#gab7fdb4362973b751c1955eb69f065f50',1,'LoadSolemioFile(char *filename):&#160;interface.cpp']]],
  ['loadsystem_120',['LoadSystem',['../group__globalc.html#ga4b9a392ad7e7eea91732bb09df055538',1,'LoadSystem(const char *filename):&#160;interface.cpp'],['../group__globalc.html#ga4b9a392ad7e7eea91732bb09df055538',1,'LoadSystem(const char *filename):&#160;interface.cpp']]],
  ['localabsoluteframe_121',['LocalAbsoluteFrame',['../group__enums.html#gga10d626c14577aaa469e804c0e08e9d38a246373ab8f221e1599be79248424840a',1,'types.h']]]
];
