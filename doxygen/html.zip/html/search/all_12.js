var searchData=
[
  ['unittype_292',['UnitType',['../group__enums.html#gacd6e2423e6b1ce5bead11cbb048ecc03',1,'types.h']]]
];
