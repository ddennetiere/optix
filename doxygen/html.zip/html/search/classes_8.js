var searchData=
[
  ['quadric_337',['Quadric',['../class_quadric.html',1,'']]]
];
