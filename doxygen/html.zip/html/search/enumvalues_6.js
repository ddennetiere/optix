var searchData=
[
  ['notoptimizable_644',['NotOptimizable',['../group__enums.html#gga7c61347857df57f65d567c1aa36aa7e0aeb4644cfa423fdf88993f1ef70d33c68',1,'types.h']]]
];
