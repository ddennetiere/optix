var searchData=
[
  ['quadric_492',['Quadric',['../class_quadric.html#a95c3ee05907c6f38a065c39aa889907d',1,'Quadric']]]
];
