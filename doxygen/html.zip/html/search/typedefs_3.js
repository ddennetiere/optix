var searchData=
[
  ['raybasetype_614',['RayBaseType',['../types_8h.html#a88efc01d733a23332ee8f78faaf559b2',1,'types.h']]],
  ['raytype_615',['RayType',['../types_8h.html#ab1093400fc3129c25525f5994194f1f2',1,'types.h']]]
];
