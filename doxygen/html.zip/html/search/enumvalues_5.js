var searchData=
[
  ['localabsoluteframe_643',['LocalAbsoluteFrame',['../group__enums.html#gga10d626c14577aaa469e804c0e08e9d38a246373ab8f221e1599be79248424840a',1,'types.h']]]
];
