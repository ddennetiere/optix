var searchData=
[
  ['recordmode_629',['RecordMode',['../group__enums.html#ga9d89dadc7eae9423d082ce4bc9bfea5a',1,'types.h']]]
];
