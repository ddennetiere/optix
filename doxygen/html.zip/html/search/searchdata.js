var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvwx~",
  1: "cdefghmpqrstwx",
  2: "cefghiopqrstw",
  3: "acdefgilmnopqrstx~",
  4: "bcfgmpstv",
  5: "cfprst",
  6: "fpru",
  7: "abdgilnrs",
  8: "o",
  9: "egi",
  10: "ot"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Modules",
  10: "Pages"
};

