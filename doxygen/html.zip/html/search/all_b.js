var searchData=
[
  ['normalized_168',['normalized',['../class_ray_base.html#a3455328b1c99f1c3773fc6d2602a68db',1,'RayBase']]],
  ['notoptimizable_169',['NotOptimizable',['../group__enums.html#gga7c61347857df57f65d567c1aa36aa7e0aeb4644cfa423fdf88993f1ef70d33c68',1,'types.h']]]
];
