var searchData=
[
  ['generalframe_640',['GeneralFrame',['../group__enums.html#gga10d626c14577aaa469e804c0e08e9d38a4660bdd26b74a6f3f9b3731dd5c28754',1,'types.h']]],
  ['gratinggroup_641',['GratingGroup',['../group__enums.html#ggabd71b1e0e3eaa825ce0dcb970e4b8c77a7f05d6fcfd709fcb6af8e043e7fc4ce6',1,'types.h']]]
];
