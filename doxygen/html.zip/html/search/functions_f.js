var searchData=
[
  ['toroid_530',['Toroid',['../class_toroid.html#a2b3b03176395badad8b191645aad5464',1,'Toroid']]],
  ['transmit_531',['transmit',['../class_grating_base.html#a0cd5d1e005e34d2e4032768174ad1bfd',1,'GratingBase::transmit()'],['../class_surface.html#ad9e068454bd2b8ccc9574b2898c18a28',1,'Surface::transmit()']]]
];
