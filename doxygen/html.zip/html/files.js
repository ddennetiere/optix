var files =
[
    [ "cylinder.cpp", "cylinder_8cpp.html", null ],
    [ "cylinder.h", "cylinder_8h.html", [
      [ "Cylinder", "class_cylinder.html", "class_cylinder" ]
    ] ],
    [ "files.h", "files_8h.html", "files_8h" ],
    [ "gratingbase.cpp", "gratingbase_8cpp.html", null ],
    [ "gratingbase.h", "gratingbase_8h.html", [
      [ "GratingBase", "class_grating_base.html", "class_grating_base" ]
    ] ],
    [ "gridSource.h", "grid_source_8h.html", [
      [ "XYGridSource", "class_x_y_grid_source.html", "class_x_y_grid_source" ],
      [ "RadialGridSource", "class_radial_grid_source.html", "class_radial_grid_source" ]
    ] ],
    [ "interface.cpp", "interface_8cpp.html", "interface_8cpp" ],
    [ "interface.h", "interface_8h.html", "interface_8h" ],
    [ "minimizable.cpp", "minimizable_8cpp.html", null ],
    [ "minimizable.h", "minimizable_8h.html", [
      [ "minimizable", "classminimizable.html", "classminimizable" ]
    ] ],
    [ "opticalelements.cpp", "opticalelements_8cpp.html", null ],
    [ "opticalelements.h", "opticalelements_8h.html", "opticalelements_8h" ],
    [ "OptixException.h", "_optix_exception_8h.html", [
      [ "RayException", "class_ray_exception.html", "class_ray_exception" ],
      [ "ParameterException", "class_parameter_exception.html", "class_parameter_exception" ],
      [ "TextFileException", "class_text_file_exception.html", "class_text_file_exception" ]
    ] ],
    [ "plane.cpp", "plane_8cpp.html", null ],
    [ "plane.h", "plane_8h.html", [
      [ "Plane", "class_plane.html", "class_plane" ]
    ] ],
    [ "quadric.cpp", "quadric_8cpp.html", null ],
    [ "quadric.h", "quadric_8h.html", [
      [ "Quadric", "class_quadric.html", "class_quadric" ]
    ] ],
    [ "ray.h", "ray_8h.html", [
      [ "Ray", "class_ray.html", "class_ray" ]
    ] ],
    [ "raybase.h", "raybase_8h.html", "raybase_8h" ],
    [ "sourcebase.cpp", "sourcebase_8cpp.html", null ],
    [ "sourcebase.h", "sourcebase_8h.html", [
      [ "SourceBase", "class_source_base.html", "class_source_base" ]
    ] ],
    [ "sphere.cpp", "sphere_8cpp.html", null ],
    [ "sphere.h", "sphere_8h.html", [
      [ "Sphere", "class_sphere.html", "class_sphere" ]
    ] ],
    [ "surface.cpp", "surface_8cpp.html", "surface_8cpp" ],
    [ "surface.h", "surface_8h.html", "surface_8h" ],
    [ "test.cpp", "test_8cpp.html", "test_8cpp" ],
    [ "toroid.cpp", "toroid_8cpp.html", "toroid_8cpp" ],
    [ "toroid.h", "toroid_8h.html", [
      [ "Toroid", "class_toroid.html", "class_toroid" ]
    ] ],
    [ "ToroidComplexSolver.cpp", "_toroid_complex_solver_8cpp.html", "_toroid_complex_solver_8cpp" ],
    [ "ToroidSolver.cpp", "_toroid_solver_8cpp.html", "_toroid_solver_8cpp" ],
    [ "types.h", "types_8h.html", "types_8h" ],
    [ "wavefront.cpp", "wavefront_8cpp.html", "wavefront_8cpp" ],
    [ "wavefront.h", "wavefront_8h.html", "wavefront_8h" ]
];