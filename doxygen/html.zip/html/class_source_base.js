var class_source_base =
[
    [ "SourceBase", "class_source_base.html#a5e89b02122d8d6e29f4ebbf751e50cab", null ],
    [ "~SourceBase", "class_source_base.html#a6b28123c48b71e2bfced0067bf697bdf", null ],
    [ "align", "class_source_base.html#a206ddf6e48078d3f12f4639bc20af77e", null ],
    [ "generate", "class_source_base.html#a29966a4d9597164af8d32184ec5e0893", null ],
    [ "intercept", "class_source_base.html#aa5031e6ba93b6ac4ecd04b15ac4a83f9", null ],
    [ "radiate", "class_source_base.html#ae940375cfb9dbef512d24b5c2c44f80a", null ],
    [ "setWavelength", "class_source_base.html#a612183e906d8d9e2136f078479192ed0", null ]
];