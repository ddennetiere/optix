var class_sphere =
[
    [ "Sphere", "class_sphere.html#a890a63ff583cb88e7ec4e840b4ef5eb9", null ],
    [ "~Sphere", "class_sphere.html#acde2697064cbc2c64ea34aed1b3efac7", null ],
    [ "createSurface", "class_sphere.html#abe6537c6159ffc9d23bc8b84c3adcf86", null ],
    [ "getOptixClass", "class_sphere.html#a331bf3fce80a13a28808d17502d696cb", null ],
    [ "setParameter", "class_sphere.html#aec3a0688f66faad735e81dd2a81821ff", null ]
];