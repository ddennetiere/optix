var class_gaussian_source =
[
    [ "GaussianSource", "class_gaussian_source.html#a891a95c85fd4011440e2e59ca980574a", null ],
    [ "~GaussianSource", "class_gaussian_source.html#a16e142efa4cfe0eeee9e9d2002fb602b", null ],
    [ "generate", "class_gaussian_source.html#a8d0e9a70d97a6c12c25f982c29450d6e", null ],
    [ "getOptixClass", "class_gaussian_source.html#a16d24f1559403a9586c8127a5bb3a963", null ]
];