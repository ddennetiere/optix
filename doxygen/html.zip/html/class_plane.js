var class_plane =
[
    [ "Plane", "class_plane.html#a5c88b49185f2dffb9656e8d23eb665c1", null ],
    [ "~Plane", "class_plane.html#a69abd86051c880dcb44b249ad10c4436", null ],
    [ "align", "class_plane.html#a3710ddd024c314bab69f2f74df034bca", null ],
    [ "getOptixClass", "class_plane.html#af3129c155279742b1b0fca77a206ad66", null ],
    [ "intercept", "class_plane.html#a2bc0812eb3f0468b2f8293c3aa24e54c", null ],
    [ "m_hyperplane", "class_plane.html#a2b09aceca571d884b0dfb8cdf813c285", null ]
];