var class_text_file_exception =
[
    [ "TextFileException", "class_text_file_exception.html#abb302347d8ff35886a894628e1dbf786", null ],
    [ "~TextFileException", "class_text_file_exception.html#ad5f10692d7e63728e4826434eeaf164e", null ],
    [ "what", "class_text_file_exception.html#aa800fee79c4123e7578a6f9b30485e21", null ],
    [ "what_str", "class_text_file_exception.html#ab18485bd4cce08bff29ae4bd0bea92bb", null ]
];