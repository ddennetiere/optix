var class_x_y_grid_source =
[
    [ "XYGridSource", "class_x_y_grid_source.html#a4182b7ee83e264c6c3e5cf3a838be627", null ],
    [ "~XYGridSource", "class_x_y_grid_source.html#aea0de5ca276710e38018278ae13fe16e", null ],
    [ "generate", "class_x_y_grid_source.html#a89bd0d5a64bd95b6da98f88d6ff3a3bd", null ],
    [ "getOptixClass", "class_x_y_grid_source.html#a23eae8f2faf881f107c916a8d2e3d068", null ],
    [ "nX", "class_x_y_grid_source.html#a8e1f632689e1e1f99370471b158bb8d5", null ],
    [ "nXprim", "class_x_y_grid_source.html#a9a2deeb661bc23aaa75622b5acb72356", null ],
    [ "nY", "class_x_y_grid_source.html#af5e62f86cd2acdea3fbf3d34749e8fe8", null ],
    [ "nYprim", "class_x_y_grid_source.html#aa4c26dee357d89fc8ee47b40352a3a07", null ]
];