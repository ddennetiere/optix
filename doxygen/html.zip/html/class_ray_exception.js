var class_ray_exception =
[
    [ "RayException", "class_ray_exception.html#a316c9da404de8617eed89c626884897b", null ],
    [ "~RayException", "class_ray_exception.html#a40b32fe6732dbc95c2e10869ea2db84f", null ],
    [ "what", "class_ray_exception.html#a03dd25bbc1f674a5abba08fc9694d5f2", null ],
    [ "what_str", "class_ray_exception.html#a101e16aa547da663885179e97f28f185", null ]
];