var class_pattern =
[
    [ "Pattern", "class_pattern.html#a95f42b0f1717d9e6c2d831e87d27f83c", null ],
    [ "~Pattern", "class_pattern.html#aaaf53c3e0bcbede30dedeb8a0ff7bd6c", null ],
    [ "gratingVector", "class_pattern.html#ab3dac7569dae2eee2fc007a98dfdc07e", null ]
];