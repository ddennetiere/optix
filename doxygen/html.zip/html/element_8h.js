var element_8h =
[
    [ "Element", "class_element.html", "class_element" ],
    [ "_SURFACE_H", "element_8h.html#add69d978cf5efc00171456b05731b6c6", null ],
    [ "oneMinusSqrt1MinusX", "element_8h.html#a425344b07cf7f57bde420fcfbb3793a7", null ]
];