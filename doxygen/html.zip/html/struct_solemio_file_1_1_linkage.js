var struct_solemio_file_1_1_linkage =
[
    [ "name", "struct_solemio_file_1_1_linkage.html#a65657e638bd833cc4b770e368a372010", null ],
    [ "next", "struct_solemio_file_1_1_linkage.html#a4d332f4a4ef8ea9c1b5055c8e6de8ad8", null ],
    [ "prev", "struct_solemio_file_1_1_linkage.html#af71ba30a0688491e9ee2b11ec9360d4b", null ]
];