var class_surface =
[
    [ "Surface", "class_surface.html#a6150b9c0e182789fa68ac8d3d347b728", null ],
    [ "~Surface", "class_surface.html#a44ff6a911acc4ada428c3d734f342a8a", null ],
    [ "align", "class_surface.html#a74db8312ba1e174e8b4dec3d59796aab", null ],
    [ "clearImpacts", "class_surface.html#a90fc5bed047cae0fdf2f54ecf6c9b324", null ],
    [ "getCaustic", "class_surface.html#a7022db44f105d0b7366f48257acd4331", null ],
    [ "getImpacts", "class_surface.html#aed73e3518de9f1cdbaf1a0c37f0eba1d", null ],
    [ "getOptixClass", "class_surface.html#a812cbcc32168ecdbf1de86411a9250c3", null ],
    [ "getRecording", "class_surface.html#a7ebd740248dca5ba725ff22a08bf401f", null ],
    [ "getSpotDiagram", "class_surface.html#ab6df295149c97194bf99172997a71fb8", null ],
    [ "getWavefontExpansion", "class_surface.html#a56a3fed6d948ee0160924de6a6020fe6", null ],
    [ "getWavefrontData", "class_surface.html#a4e689844bea2157b3d528273bc3c2693", null ],
    [ "intercept", "class_surface.html#ac81115fd98287569a5f3e88bb41d2cd0", null ],
    [ "propagate", "class_surface.html#a8f928cd39c5bbdbeab28e6ac551d0a0a", null ],
    [ "reflect", "class_surface.html#a057a0a10cd60e9cfbce7b91b27c9c716", null ],
    [ "reserveImpacts", "class_surface.html#a0c6781b76befc519cc5dd8f151a29fb2", null ],
    [ "setRecording", "class_surface.html#ab985bb070bbc7d9e7378dbeb1202543e", null ],
    [ "sizeImpacts", "class_surface.html#a27c591b3cb6e57a8ad5b19a198f97e41", null ],
    [ "transmit", "class_surface.html#ad9e068454bd2b8ccc9574b2898c18a28", null ],
    [ "m_impacts", "class_surface.html#a57846258060b17793aa3a2932e48cbff", null ],
    [ "m_recording", "class_surface.html#a49075cc2c3488f181f03aecd10352612", null ]
];