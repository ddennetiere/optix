var struct_chain_copy =
[
    [ "~ChainCopy", "struct_chain_copy.html#a1ad3a3d53fe13967eba7cceb5a7aa9a9", null ],
    [ "copyMap", "struct_chain_copy.html#ac7791763ee82396c6119084477c74313", null ],
    [ "First", "struct_chain_copy.html#a596dec6ad841d49f53c7e5aabb42d2f7", null ]
];