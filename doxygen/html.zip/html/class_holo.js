var class_holo =
[
    [ "Holo", "class_holo.html#a84875d2bc0326278e4a88adaf8a9d561", null ],
    [ "~Holo", "class_holo.html#ad4da2a71fa236393ecb1eaf682360894", null ],
    [ "defineDirection2", "class_holo.html#abd70edb5b018c163b39a90b70b5c078d", null ],
    [ "getOptixClass", "class_holo.html#ae21ec07fe85957cc91185beb86fa89e8", null ],
    [ "gratingVector", "class_holo.html#af15ac8cc2c59298da7f9bcab12a0d839", null ],
    [ "setParameter", "class_holo.html#a958026d8491b15a503699eca7b5ad5c2", null ],
    [ "m_direction1", "class_holo.html#ab39da91159e0882cd3621958ff8cd0c5", null ],
    [ "m_direction2", "class_holo.html#ae7bf075ec5d7c51abb4ddefaecb161a4", null ],
    [ "m_holoWavelength", "class_holo.html#aaf80acd94aa6d7157cb26860dd3a3832", null ],
    [ "m_inverseDistance1", "class_holo.html#a8d3ae3b1553ca24cb5c8ce7a08ebf1c3", null ],
    [ "m_inverseDistance2", "class_holo.html#ade50211e9b61de05ce3583305a89376d", null ],
    [ "m_lineDensity", "class_holo.html#ae9622fd22bd27f519f0b0afb2e65ff7c", null ]
];