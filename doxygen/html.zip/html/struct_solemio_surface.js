var struct_solemio_surface =
[
    [ "SolemioSurface", "struct_solemio_surface.html#ad48cd07a97454e55fee5ff3fea606e34", null ],
    [ "ReadFromFile", "struct_solemio_surface.html#ac25f833bf856bcc14c52f5c4e71a46c4", null ],
    [ "coatingset", "struct_solemio_surface.html#a3a6bb1f072b89ba79b44375d8a9e1239", null ],
    [ "coparam", "struct_solemio_surface.html#a6bcfa97c26da21059eca6a9fa24177cd", null ],
    [ "coparmax", "struct_solemio_surface.html#a080c45ff6ab907836c530d10382ec043", null ],
    [ "coparmin", "struct_solemio_surface.html#a5b2ec4df0ce57a6f0cb58757d8f2a46f", null ],
    [ "coparmisvariable", "struct_solemio_surface.html#a4bb32381d8d983540295d83b3a3074e7", null ],
    [ "nomemezzo1", "struct_solemio_surface.html#acf2bafd6562d5f189584f4c9260fc45a", null ],
    [ "nomemezzo2", "struct_solemio_surface.html#aed3ae963d275a741cffdbaed1f912971", null ],
    [ "option", "struct_solemio_surface.html#a19efe85914e601bff1846d584fac6a5c", null ],
    [ "param", "struct_solemio_surface.html#a56e6e3d408440c171e2108fa84409bdd", null ],
    [ "parmisvariable", "struct_solemio_surface.html#a829bb5dc00ad02f106edd5d3f46e3aa0", null ],
    [ "type", "struct_solemio_surface.html#a3835bd78b61813412411cba465899c11", null ],
    [ "varparamax", "struct_solemio_surface.html#aa84ea8b6104f0b5ccd1eef08f4b3482c", null ],
    [ "varparamin", "struct_solemio_surface.html#a054d3291308e392d614d95abb25ac225", null ]
];