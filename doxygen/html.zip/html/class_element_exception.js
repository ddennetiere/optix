var class_element_exception =
[
    [ "ElementException", "class_element_exception.html#aa0bbc3e7a9b2499498c729464b183611", null ],
    [ "~ElementException", "class_element_exception.html#aa95772cbb8a8d15fc1e1b90e8ea8ea1e", null ],
    [ "what", "class_element_exception.html#aeb7084480c888291fcee48931194e323", null ],
    [ "what_str", "class_element_exception.html#ae992e818c0f4c6c4427af47d0754f0a8", null ]
];