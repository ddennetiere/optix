var files_dup =
[
    [ "collections.h", "collections_8h.html", [
      [ "ElementCollection", "class_element_collection.html", "class_element_collection" ],
      [ "StringVector", "class_string_vector.html", "class_string_vector" ]
    ] ],
    [ "cylinder.cpp", "cylinder_8cpp.html", null ],
    [ "cylinder.h", "cylinder_8h.html", "cylinder_8h" ],
    [ "elementbase.cpp", "elementbase_8cpp.html", "elementbase_8cpp" ],
    [ "elementbase.h", "elementbase_8h.html", "elementbase_8h" ],
    [ "files.cpp", "files_8cpp.html", "files_8cpp" ],
    [ "files.h", "files_8h.html", "files_8h" ],
    [ "gratingbase.cpp", "gratingbase_8cpp.html", null ],
    [ "gratingbase.h", "gratingbase_8h.html", "gratingbase_8h" ],
    [ "holo.cpp", "holo_8cpp.html", "holo_8cpp" ],
    [ "holo.h", "holo_8h.html", "holo_8h" ],
    [ "interface.cpp", "interface_8cpp.html", "interface_8cpp" ],
    [ "interface.h", "interface_8h.html", "interface_8h" ],
    [ "opticalelements.cpp", "opticalelements_8cpp.html", "opticalelements_8cpp" ],
    [ "opticalelements.h", "opticalelements_8h.html", "opticalelements_8h" ],
    [ "OptixException.h", "_optix_exception_8h.html", [
      [ "ElementException", "class_element_exception.html", "class_element_exception" ],
      [ "ParameterException", "class_parameter_exception.html", "class_parameter_exception" ],
      [ "RayException", "class_ray_exception.html", "class_ray_exception" ],
      [ "TextFileException", "class_text_file_exception.html", "class_text_file_exception" ]
    ] ],
    [ "plane.cpp", "plane_8cpp.html", null ],
    [ "plane.h", "plane_8h.html", "plane_8h" ],
    [ "Poly1D.cpp", "_poly1_d_8cpp.html", null ],
    [ "Poly1D.h", "_poly1_d_8h.html", "_poly1_d_8h" ],
    [ "quadric.cpp", "quadric_8cpp.html", null ],
    [ "quadric.h", "quadric_8h.html", [
      [ "Quadric", "class_quadric.html", "class_quadric" ]
    ] ],
    [ "ray.h", "ray_8h.html", [
      [ "Ray", "class_ray.html", "class_ray" ]
    ] ],
    [ "raybase.h", "raybase_8h.html", "raybase_8h" ],
    [ "SolemioTest.cpp", "_solemio_test_8cpp.html", "_solemio_test_8cpp" ],
    [ "sourcebase.cpp", "sourcebase_8cpp.html", null ],
    [ "sourcebase.h", "sourcebase_8h.html", [
      [ "SourceBase", "class_source_base.html", "class_source_base" ]
    ] ],
    [ "sources.cpp", "sources_8cpp.html", null ],
    [ "sources.h", "sources_8h.html", [
      [ "GaussianSource", "class_gaussian_source.html", "class_gaussian_source" ],
      [ "RadialGridSource", "class_radial_grid_source.html", "class_radial_grid_source" ],
      [ "XYGridSource", "class_x_y_grid_source.html", "class_x_y_grid_source" ]
    ] ],
    [ "sphere.cpp", "sphere_8cpp.html", null ],
    [ "sphere.h", "sphere_8h.html", "sphere_8h" ],
    [ "surface.cpp", "surface_8cpp.html", null ],
    [ "surface.h", "surface_8h_source.html", null ],
    [ "test.cpp", "test_8cpp.html", "test_8cpp" ],
    [ "toroid.cpp", "toroid_8cpp.html", "toroid_8cpp" ],
    [ "toroid.h", "toroid_8h.html", "toroid_8h" ],
    [ "ToroidComplexSolver.cpp", "_toroid_complex_solver_8cpp.html", "_toroid_complex_solver_8cpp" ],
    [ "ToroidSolver.cpp", "_toroid_solver_8cpp.html", "_toroid_solver_8cpp" ],
    [ "types.h", "types_8h.html", "types_8h" ],
    [ "wavefront.cpp", "wavefront_8cpp.html", "wavefront_8cpp" ],
    [ "wavefront.h", "wavefront_8h.html", "wavefront_8h" ]
];