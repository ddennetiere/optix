var files_8h =
[
    [ "SolemioFile", "class_solemio_file.html", "class_solemio_file" ],
    [ "TextFile", "class_text_file.html", "class_text_file" ],
    [ "ReadSolemioFile", "files_8h.html#a7ad37ad0c1ff66aff96dcc945a558b7f", null ],
    [ "SolemioImport", "files_8h.html#a56b7b7468830b500c52a0ccc3ec5b2a7", null ]
];