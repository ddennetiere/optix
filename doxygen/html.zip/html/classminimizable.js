var classminimizable =
[
    [ "minimizable", "classminimizable.html#a64f22f3152a25b94fbd0d72854f29880", null ],
    [ "getStopFlag", "classminimizable.html#ae4b12156ebdf4622cb1761a8f84d567e", null ],
    [ "scarto", "classminimizable.html#a8c97577d986f7422e9a3b94aec29373d", null ],
    [ "setStopFlag", "classminimizable.html#ac5a380736c4a7f5a92db547bb50d03f1", null ],
    [ "StopFlag", "classminimizable.html#a92bbb1f9bd9a51c63dcd4c9dd9a6bf10", null ]
];