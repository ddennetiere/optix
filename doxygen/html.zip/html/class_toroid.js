var class_toroid =
[
    [ "Toroid", "class_toroid.html#a2b3b03176395badad8b191645aad5464", null ],
    [ "~Toroid", "class_toroid.html#a3dfaa9e15069249990a172e61e4518b4", null ],
    [ "align", "class_toroid.html#ad7cb2070eb9e7ae2fd1d2ac5166bd2be", null ],
    [ "createSurface", "class_toroid.html#a794fbed326b957a8adfece15e4f59c1e", null ],
    [ "getOptixClass", "class_toroid.html#a906e2342ed4efdd5f9dcd7bbc801e1ad", null ],
    [ "intercept", "class_toroid.html#adc2aee24ece161279cf50f9c14218b6e", null ],
    [ "setParameter", "class_toroid.html#ae1210bbf9be9cb7767e2009515761d69", null ],
    [ "m_alignedMat1", "class_toroid.html#ab69df7ffe925460531c60b1738114f31", null ],
    [ "m_alignedMat2", "class_toroid.html#aa024d5aa2ff9db2f6dc460c15ee2928f", null ],
    [ "m_toreMat1", "class_toroid.html#a71d566d2ac46f110182e0f508f80587a", null ],
    [ "m_toreMat2", "class_toroid.html#a39b3737d3729ec4d59d9160bfdbf86e4", null ]
];