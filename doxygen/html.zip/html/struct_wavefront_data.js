var struct_wavefront_data =
[
    [ "operator<<", "struct_wavefront_data.html#a63e13f0d8def698dc23728e36029ad6b", null ],
    [ "m_bounds", "struct_wavefront_data.html#a0d508ae6c366a52b55a497f6b162d47e", null ],
    [ "m_WFdata", "struct_wavefront_data.html#aeed5c502eb5ac2e0614e4097a7cec1b5", null ]
];