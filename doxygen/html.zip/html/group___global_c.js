var group___global_c =
[
    [ "CreateElementObject", "group___global_c.html#gace2d07da4219e62bbad6f6145da91ab0", null ],
    [ "MakeGratingTransmissive", "group___global_c.html#gaf71a211d03ce7611d703e08b2c48da3a", null ],
    [ "oneMinusSqrt1MinusX", "group___global_c.html#ga425344b07cf7f57bde420fcfbb3793a7", null ],
    [ "SetOptiXLastError", "group___global_c.html#ga6d825b54f0e504714ac2bf3ab3cf0265", null ]
];