var class_film =
[
    [ "Film", "class_film.html#aaf008b78e2fbcb1c017e514b37dfc27b", null ],
    [ "~Film", "class_film.html#a8ac5d46585541b4ccd703794c223822e", null ],
    [ "align", "class_film.html#a11d667432a747030181218a8ce29ecf0", null ],
    [ "getOptixClass", "class_film.html#ad1151ab6f1c170a6e879d9bbf3797bb5", null ]
];