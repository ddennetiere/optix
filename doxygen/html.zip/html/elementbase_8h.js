var elementbase_8h =
[
    [ "ElementBase", "class_element_base.html", "class_element_base" ],
    [ "ClearOptiXError", "elementbase_8h.html#a2797c5aa9fc5113a3ce8f771ecf091de", null ],
    [ "oneMinusSqrt1MinusX", "group___global_cpp.html#ga425344b07cf7f57bde420fcfbb3793a7", null ],
    [ "SetOptiXLastError", "group___global_cpp.html#ga6d825b54f0e504714ac2bf3ab3cf0265", null ],
    [ "LastError", "elementbase_8h.html#abd7770a7a5f5afcdf6c96c63b750b95b", null ],
    [ "OptiXError", "elementbase_8h.html#ace1b47618c2b47fadf8dc75a603efb94", null ]
];