var class_surface_collection =
[
    [ "SurfaceCollection", "class_surface_collection.html#a3e4164e5cbd2a2d4eececcfee941be41", null ],
    [ "~SurfaceCollection", "class_surface_collection.html#a5ff48a5e0cb25792c07a3570656f48e2", null ],
    [ "clear", "class_surface_collection.html#a97995ea47c4c94cb97ce86cfa454fcbf", null ],
    [ "erase", "class_surface_collection.html#a358ab4a5805dd61107f7adeaa5dbb6df", null ],
    [ "erase", "class_surface_collection.html#a18dbbcbef10e26fcdeaaadadd852ebd9", null ],
    [ "erase", "class_surface_collection.html#a06f848ebf979904999bf830caf45593e", null ]
];