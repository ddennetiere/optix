var struct_c___link_type =
[
    [ "name", "struct_c___link_type.html#af1c10b7bb7edda397580c3a003bb0898", null ],
    [ "next", "struct_c___link_type.html#a8e43010d2d580bfea56c356ac7af7a8f", null ],
    [ "parent", "struct_c___link_type.html#ac0147e98917cd6a6b50a360a7b0996ca", null ],
    [ "prev", "struct_c___link_type.html#aae794a11fa59038a8e3d0a3587c92cbb", null ]
];