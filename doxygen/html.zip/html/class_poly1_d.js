var class_poly1_d =
[
    [ "Poly1D", "class_poly1_d.html#aecd1412f00d301cf94946061d2dfc67b", null ],
    [ "~Poly1D", "class_poly1_d.html#a3950b69cd8e06d323f2bda376698aa29", null ],
    [ "getOptixClass", "class_poly1_d.html#a2113d4f3198fb609c7c6983796ee4fa0", null ],
    [ "gratingVector", "class_poly1_d.html#a43ffe114fa60cc9020c6582343be4932", null ],
    [ "setParameter", "class_poly1_d.html#a4b7b25d3c0e8e678ad11853e454037e4", null ],
    [ "m_coeffs", "class_poly1_d.html#a5d9f136b21b7354fbd3b4b23f24e889a", null ],
    [ "m_degree", "class_poly1_d.html#a2d379a78a024fa7df60c93e9d0667d51", null ]
];