var class_mirror =
[
    [ "Mirror", "class_mirror.html#a2417ebd26bd1aa041bbeab87acba8d0f", null ],
    [ "~Mirror", "class_mirror.html#ae1481c49fa67f3e0b9bebea89e30084b", null ],
    [ "align", "class_mirror.html#ae15ea8e2bda7ad42e0c0dce0ef5c96fd", null ],
    [ "getOptixClass", "class_mirror.html#a890982007115dfc405c929cafaa3e903", null ]
];