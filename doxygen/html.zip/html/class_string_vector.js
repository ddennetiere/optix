var class_string_vector =
[
    [ "~StringVector", "class_string_vector.html#a064d3438c6b305e9ea5c82012292cd8d", null ],
    [ "erase", "class_string_vector.html#a97dc38badb2c4f699b2739e825b60c24", null ],
    [ "erase", "class_string_vector.html#ae8791e7b5d8ae2320a47786961e72428", null ]
];