var class_quadric =
[
    [ "Quadric", "class_quadric.html#a95c3ee05907c6f38a065c39aa889907d", null ],
    [ "~Quadric", "class_quadric.html#a4550e4e9eee3832eda3cbac34829e2dd", null ],
    [ "align", "class_quadric.html#ac4b8bbcc9c4f069e3c22f9214c053898", null ],
    [ "getOptixClass", "class_quadric.html#a79fd961ecea36f8f05b3b086214c83ad", null ],
    [ "intercept", "class_quadric.html#a39a6018ce6a029ccb3b3f0f6668efac1", null ],
    [ "m_alignedQuadric", "class_quadric.html#ac8ae282b8bfd73ad1dc995c79aef3e03", null ],
    [ "m_localQuadric", "class_quadric.html#a349265152d32b595a4cf2d52662467ac", null ]
];